@echo off
setlocal

set one_home=%cd%

if exist *~ (
    del *~
)

if exist *.zip (
    del *.zip
)

if exist log.txt (
    del log.txt
)

cd ..
tar -c -f one-release.zip one
@move one-release.zip one
cd %one_home%


endlocal
